// 파이(π) 값을 소수점 다섯째 자리까지 출력하라.
import { question } from "readline-sync";

const PI = Math.PI;

console.log(`파이(π) 소수점 다섯째 자리까지 출력 = ${PI.toFixed(5)} 입니다. `);
